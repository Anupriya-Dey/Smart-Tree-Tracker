# Copyright contributors to the TSFM project
#
from tsfm_public.models.tinytimemixer.utils.ttm_args import get_ttm_args
