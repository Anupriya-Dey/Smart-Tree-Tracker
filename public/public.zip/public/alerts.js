// alerts.js

const GLOBAL_TEMP_THRESHOLD = 100;      // in °C
const GLOBAL_PRESSURE_THRESHOLD = 90;   // in kPa
const ORIGIN_LAT = 29.87;
const ORIGIN_LON = 77.9;
const GLOBAL_GPS_SPEED_THRESHOLD = 10;
const GLOBAL_GPS_ALTITUDE_THRESHOLD = 265;

// Temperature Alert
function checkForTemperatureAlert(data) {
  const latestTemp = data.latest;
  if (latestTemp > GLOBAL_TEMP_THRESHOLD) {
    console.log(`Temperature: ${latestTemp}°C`);
    showForestFireBanner();
    socket.emit('sendTemperatureAlert', { temperature: latestTemp });
  }
}

// Pressure Alert
function checkForPressureAlert(data) {
  const latestPressure = data.latest;
  if (latestPressure < GLOBAL_PRESSURE_THRESHOLD) {
    console.log(`Pressure: ${latestPressure} kPa`);
    showPressureAlertBanner();
    socket.emit('sendPressureAlert', { pressure: latestPressure });
  }
}

// GPS_Speed Alert
function checkForGPS_SpeedAlert(data) {
  const latestGPS_Speed = data.latest;
  if (latestGPS_Speed > GLOBAL_GPS_SPEED_THRESHOLD) {
    console.log(`GPS_Speed: ${latestGPS_Speed} km/h`);
    showGPS_SpeedAlertBanner();
    socket.emit('sendGPS_SpeedAlert', { gps_speed: latestGPS_Speed });
  }
}

// GPS_Altitude Alert
function checkForGPS_AltitudeAlert(data) {
  const latestGPS_Altitude = data.latest;
  if (latestGPS_Altitude < GLOBAL_GPS_ALTITUDE_THRESHOLD) {
    console.log(`GPS_Altitude: ${latestGPS_Altitude} m`);
    showGPS_AltitudeAlertBanner();
    socket.emit('sendGPS_AltitudeAlert', { gps_altitude: latestGPS_Altitude });
  }
}

// GPS Position Alert

function triggerPositionCheckIfReady() {
  if (latestLatitude !== null && latestLongitude !== null) {
    checkForPositionAlert({
      latest_lat: latestLatitude,
      latest_lon: latestLongitude
    });
  }
}

function checkForPositionAlert(data) {
  const latestLat = data.latest_lat;
  const latestLon = data.latest_lon;

  const latDiff = Math.abs(latestLat - ORIGIN_LAT);
  const lonDiff = Math.abs(latestLon - ORIGIN_LON);

  if (latDiff > 0.009 || lonDiff > 0.0089) {
    console.log(`Position Alert: Latitude or Longitude deviation too high!`);
    showPositionAlertBanner();
    socket.emit('sendPositionAlert', {
      latitude: latestLat,
      longitude: latestLon
    });
  }
}


// Forest Fire Banner
function showForestFireBanner() {
  if (document.getElementById("forestFireBanner")) return;

  const banner = document.createElement("div");
  banner.id = "forestFireBanner";
  banner.innerHTML = `
    <span>🔥 Forest Fire Alert! Temperature exceeds 100°C!</span>
    <button id="closeBanner" style="margin-left: 20px; background-color: #0000aa; color: #fff; padding: 5px 10px; border: none; cursor: pointer;">Close</button>
  `;

  styleBanner(banner);
  document.body.appendChild(banner);

  document.getElementById("closeBanner").addEventListener("click", () => {
    banner.remove();
  });
}

// Pressure Alert Banner
function showPressureAlertBanner() {
  if (document.getElementById("pressureBanner")) return;

  const banner = document.createElement("div");
  banner.id = "pressureBanner";
  banner.innerHTML = `
    <span>⚠️ Pressure Alert! Atmospheric pressure is below ${GLOBAL_PRESSURE_THRESHOLD} kPa!</span>
    <button id="closePressureBanner" style="margin-left: 20px; background-color: #0000aa; color: #fff; padding: 5px 10px; border: none; cursor: pointer;">Close</button>
  `;

  styleBanner(banner);
  document.body.appendChild(banner);

  document.getElementById("closePressureBanner").addEventListener("click", () => {
    banner.remove();
  });
}

// GPS_Altitude Alert Banner
function showGPS_AltitudeAlertBanner() {
  if (document.getElementById("altitudeBanner")) return;

  const banner = document.createElement("div");
  banner.id = "altitudeBanner";
  banner.innerHTML = `
    <span>🗻 Altitude Alert! Unusual altitude detected!</span>
    <button id="closeAltitudeBanner" style="margin-left: 20px; background-color: #0000aa; color: #fff; padding: 5px 10px; border: none; cursor: pointer;">Close</button>
  `;

  styleBanner(banner);
  document.body.appendChild(banner);

  document.getElementById("closeAltitudeBanner").addEventListener("click", () => {
    banner.remove();
  });
}

// GPS_Speed Alert Banner
function showGPS_SpeedAlertBanner() {
  if (document.getElementById("speedBanner")) return;

  const banner = document.createElement("div");
  banner.id = "speedBanner";
  banner.innerHTML = `
    <span>🚗 Speed Alert! Speed exceeds ${GLOBAL_GPS_SPEED_THRESHOLD} km/h!</span>
    <button id="closeSpeedBanner" style="margin-left: 20px; background-color: #0000aa; color: #fff; padding: 5px 10px; border: none; cursor: pointer;">Close</button>
  `;

  styleBanner(banner);
  document.body.appendChild(banner);

  document.getElementById("closeSpeedBanner").addEventListener("click", () => {
    banner.remove();
  });
}

// GPS Position Alert Banner
function showPositionAlertBanner() {
  if (document.getElementById("positionBanner")) return;

  const banner = document.createElement("div");
  banner.id = "positionBanner";
  banner.innerHTML = `
    <span>📍 Position Alert! Device has moved from original location!</span>
    <button id="closePositionBanner" style="margin-left: 20px; background-color: #0000aa; color: #fff; padding: 5px 10px; border: none; cursor: pointer;">Close</button>
  `;

  styleBanner(banner);
  document.body.appendChild(banner);

  document.getElementById("closePositionBanner").addEventListener("click", () => {
    banner.remove();
  });
}

// Shared styling function
function styleBanner(banner) {
  banner.style.position = "fixed";
  banner.style.top = "0";
  banner.style.left = "0";
  banner.style.width = "100%";
  banner.style.backgroundColor = "#ff4d4d";
  banner.style.color = "#fff";
  banner.style.fontWeight = "bold";
  banner.style.padding = "1rem";
  banner.style.textAlign = "center";
  banner.style.zIndex = "9999";
  banner.style.boxShadow = "0 2px 10px rgba(0,0,0,0.5)";
  banner.style.fontSize = "1.2rem";
}
